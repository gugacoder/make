PackDm
======

Gerenciador simplificado de dependências do Framework.Net.

O projeto está disponível no repositório subversion:

- http://serverpro.processa.com/svn/fabrica/tools/pack-dm

O pacote deb pode ser baixado a partir do local:

- https://serverpro.processa.com/svn/fabrica/tools/pack-dm/deb-package/target/pack-dm-0.1-all.deb

---
Jun/2016  
Guga Coder
